﻿using System.Net.Sockets;

Console.WriteLine("TCP Client");

TcpClient client = new TcpClient("127.0.0.1", 12345);
NetworkStream ns = client.GetStream();
StreamReader reader = new StreamReader(ns);
StreamWriter writer = new StreamWriter(ns) { AutoFlush = true };

string message;
while (true)
{
    message = reader.ReadLine();
    Console.WriteLine("Server: " + message);

    string input = Console.ReadLine();
    writer.WriteLine(input);
    writer.Flush();

    if (input.ToLower() == "cancel")
    {
        break;
    }

    message = reader.ReadLine();
    Console.WriteLine("Server: " + message);
}

client.Close();
Console.WriteLine("client disconnected");