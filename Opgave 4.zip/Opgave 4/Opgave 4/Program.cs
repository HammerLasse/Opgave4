﻿using System.Net;
using System.Net.Sockets;

Console.WriteLine("TCP Server");

TcpListener Listener = new TcpListener(IPAddress.Any, 12345);
Listener.Start();
TcpClient socket = Listener.AcceptTcpClient();
NetworkStream ns = socket.GetStream();

StreamReader reader = new StreamReader(ns);
StreamWriter writer = new StreamWriter(ns) { AutoFlush = true };

string message;
while (true)
{
    writer.WriteLine("Choose one of the following actions: Random, Add, Subtract. Or write cancel to stop");

    message = reader.ReadLine()?.ToLower();

    if (message != null)
    {
        if (message == "cancel")
        {
            Console.WriteLine("Connection disconnected");
            break;
        }

        if (message != "random" && message != "add" && message != "subtract")
        {
            writer.WriteLine("needs to be either random, add or subtract");
            continue;
        }

        writer.WriteLine("type your first number: ");
        string firstNumber = reader.ReadLine();
        if (!int.TryParse(firstNumber, out int firstNumberInt))
        {
            writer.WriteLine("needs to be a number");
            continue;
        }

        writer.WriteLine("type your second number: ");
        string secondNumber = reader.ReadLine();
        if (!int.TryParse(secondNumber, out int secondNumberInt))
        {
            writer.WriteLine("needs to be a number");
            continue;
        }

        string result;
        Random random = new Random();
        switch (message)
        {
            case "random":
                result = random.Next(firstNumberInt, secondNumberInt).ToString();
                break;
            case "add":
                result = (firstNumberInt + secondNumberInt).ToString();
                break;
            case "subtract":
                result = (firstNumberInt - secondNumberInt).ToString();
                break;
            default:
                result = "wrong input try again";
                break;
        }

        writer.WriteLine("Result: " + result);
    }
    else
    {
        Console.WriteLine("Connection disconnected");
        break;
    }
}

socket.Close();
Listener.Stop();
Console.WriteLine("Server is closed");
